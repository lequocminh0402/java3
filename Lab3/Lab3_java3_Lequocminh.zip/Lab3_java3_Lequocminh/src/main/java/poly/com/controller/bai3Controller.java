package poly.com.controller;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.eclipse.tags.shaded.org.apache.bcel.generic.NEW;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet({"/bai3","/bai4"})
public class bai3Controller extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String chon= req.getRequestURI();
		if (chon.contains("/bai3")) {
			
		
		Map<String,Object> map = new HashMap<>();
		map.put("name", "iphone 17 pro max ");
		map.put("price", "25000000 VND");
		map.put("date", new Date());
		req.setAttribute("item", map);
		
		req.getRequestDispatcher("bai3.jsp").forward(req, resp);
		}
		else {
			Map<String,Object> map = new HashMap<>();
			map.put("title", "Tiêu đề bản tin");
			map.put("content", "Nhóm thanh niên ở xã Krông Năng (tỉnh Đắk Lắk) kéo đến hội chợ thương mại quấy phá,"
					+ "đe dọa tiểu thương để đòi tiền bảo kê, bị công an bắt quả tang khi đang nhận 30 triệu đồng.");
			req.setAttribute("item", map);
			req.getRequestDispatcher("bai4.jsp").forward(req, resp);
		}
	}
}
