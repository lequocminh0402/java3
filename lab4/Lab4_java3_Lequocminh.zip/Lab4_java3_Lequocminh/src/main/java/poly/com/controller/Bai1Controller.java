package poly.com.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/account/login")
public class Bai1Controller extends HttpServlet {
	
	 
	    
	    // Khối doGet (Xử lý request GET)
	    @Override
	    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	        // TODO Auto-generated method stub
	        req.setAttribute("message", "Enter username");
	        req.getRequestDispatcher("/account/Login.jsp").forward(req, resp);
	    }

	    // Khối doPost (Xử lý request POST)
	    @Override
	    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	        // TODO Auto-generated method stub
	        
	        String username = req.getParameter("username");
	        String password = req.getParameter("password");

	        // Kiểm tra thông tin đăng nhập
	        if (username.equalsIgnoreCase("Giabao") && password.equals("123")) {
	            req.setAttribute("message", "Login successfully");
	        } else {
	            req.setAttribute("message", "Invalid username or password");
	        }
	        
	        // Chuyển hướng về trang login.jsp
	        req.getRequestDispatcher("/account/Login.jsp").forward(req, resp);
	    }
	}

