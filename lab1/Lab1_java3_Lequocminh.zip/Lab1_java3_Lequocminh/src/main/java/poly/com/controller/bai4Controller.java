package poly.com.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet({"/bai4","/crud/them","/crud/xoa","/crud/sua"})
public class bai4Controller extends HttpServlet 
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.getRequestDispatcher("bai4.jsp").forward(req, resp);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 String uri = req.getRequestURI();
		 
		 if (uri.contains("/crud/them"))
		        resp.getWriter().println("<h1> Create new  ...... </h1>");
		    else if (uri.contains("/crud/xoa"))
		        resp.getWriter().println("<h1> Delete  ...... </h1>");
		    else if (uri.contains("/crud/sua"))
		        resp.getWriter().println("<h1> Update ...... </h1>");
		    else
		        resp.getWriter().println("<h1> I don't know </h1>");
	}

}
